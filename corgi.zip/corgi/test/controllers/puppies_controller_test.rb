require 'test_helper'

class PuppiesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
