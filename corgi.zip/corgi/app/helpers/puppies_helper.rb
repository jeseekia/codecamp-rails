module PuppiesHelper
end
